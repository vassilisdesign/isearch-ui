<?php
/**
 * VASSILISDESIGN Elementor widgets. Each widget outputs the design system's markup and relies on
 * the theme stylesheet only (no per-widget CSS or JS), so pages stay light.
 *
 * @package vassilisdesign-elements
 */

defined( 'ABSPATH' ) || exit;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;
use Elementor\Widget_Base;

function vde_widget_classes() {
	return array(
		'VDE_Widget_Hero',
		'VDE_Widget_Section_Head',
		'VDE_Widget_Works_Grid',
		'VDE_Widget_Logo_Wall',
		'VDE_Widget_Numbered_List',
		'VDE_Widget_Studio',
		'VDE_Widget_Client_Index',
		'VDE_Widget_Contact_Intro',
		'VDE_Widget_Work_Header',
		'VDE_Widget_Work_Intro',
		'VDE_Widget_Work_Gallery',
		'VDE_Widget_Next_Work',
		'VDE_Widget_Works_Archive',
	);
}

abstract class VDE_Widget extends Widget_Base {
	public function get_categories() {
		return array( 'vassilisdesign-elements' );
	}
	public function get_icon() {
		return 'eicon-font';
	}
	public function has_widget_inner_wrapper(): bool {
		return false;
	}
	protected function is_dynamic_content(): bool {
		return false;
	}
	/** Image markup from a MEDIA control value. */
	protected function media_img( $media, $size = 'large', $eager = false, $alt = '' ) {
		if ( ! empty( $media['id'] ) ) {
			return vde_img( $media['id'], $size, $eager, $alt );
		}
		if ( ! empty( $media['url'] ) ) {
			return sprintf( '<img class="vd-photo-img" src="%s" alt="%s" loading="%s" decoding="async">', esc_url( $media['url'] ), esc_attr( $alt ), $eager ? 'eager' : 'lazy' );
		}
		return '';
	}
	/**
	 * Style tab: font and colour controls for each part of the widget, scoped to this widget only.
	 * Items: array( 'text', key, label, selector ) adds Typography + Color;
	 *        array( 'color', key, label, selector, css property ) adds one colour.
	 */
	protected function add_style_controls( array $items ) {
		if ( ! $items ) {
			return;
		}
		$this->start_controls_section(
			'vd_style',
			array(
				'label' => __( 'Fonts and colours', 'vassilisdesign-elements' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);
		foreach ( $items as $i => $item ) {
			$selector = implode( ', ', array_map( function ( $part ) {
				return '{{WRAPPER}} ' . trim( $part );
			}, explode( ',', $item[3] ) ) );
			if ( 'text' === $item[0] ) {
				$this->add_control( $item[1] . '_heading', array( 'label' => $item[2], 'type' => Controls_Manager::HEADING, 'separator' => $i ? 'before' : 'none' ) );
				$this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => $item[1] . '_typography', 'selector' => $selector ) );
				$this->add_control( $item[1] . '_color', array( 'label' => __( 'Colour', 'vassilisdesign-elements' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( $selector => 'color: {{VALUE}} !important;' ) ) );
			} else {
				$this->add_control( $item[1], array( 'label' => $item[2], 'type' => Controls_Manager::COLOR, 'separator' => 'before', 'selectors' => array( $selector => $item[4] . ': {{VALUE}} !important;' ) ) );
			}
		}
		$this->end_controls_section();
	}
	protected function start( $label ) {
		$this->start_controls_section( 'content', array( 'label' => $label ) );
	}
}

/* ---------- Hero ---------- */

class VDE_Widget_Hero extends VDE_Widget {
	public function get_name() {
		return 'vd-hero';
	}
	public function get_title() {
		return __( 'VD Hero', 'vassilisdesign-elements' );
	}
	protected function register_controls() {
		$this->start( __( 'Hero', 'vassilisdesign-elements' ) );
		$this->add_control( 'line1', array( 'label' => __( 'Wordmark line 1', 'vassilisdesign-elements' ), 'type' => Controls_Manager::TEXT, 'default' => 'VASSILIS' ) );
		$this->add_control( 'line2', array( 'label' => __( 'Wordmark line 2', 'vassilisdesign-elements' ), 'type' => Controls_Manager::TEXT, 'default' => 'DESIGN' ) );
		$this->add_control( 'label', array( 'label' => __( 'Accessible name', 'vassilisdesign-elements' ), 'type' => Controls_Manager::TEXT, 'default' => 'VASSILISDESIGN, independent design studio' ) );
		$this->add_control( 'lead', array( 'label' => __( 'Positioning', 'vassilisdesign-elements' ), 'type' => Controls_Manager::TEXTAREA, 'default' => "Independent design studio.\nDistinctive identities.\nMeaningful design." ) );
		$this->add_control( 'meta_a', array( 'label' => __( 'Column 1', 'vassilisdesign-elements' ), 'type' => Controls_Manager::TEXTAREA, 'default' => "Brand identity\nPackaging and labels\nEditorial and print\nWeb design\nDigital communication" ) );
		$this->add_control( 'meta_b', array( 'label' => __( 'Column 2', 'vassilisdesign-elements' ), 'type' => Controls_Manager::TEXTAREA, 'default' => "Based in Greece\nClients in Greece, the US and the UK" ) );
		$this->add_control( 'vertical', array( 'label' => __( 'Vertical text', 'vassilisdesign-elements' ), 'type' => Controls_Manager::TEXTAREA, 'default' => "Independent design studio\nGreece and the United States" ) );
		$this->add_control( 'corner', array( 'label' => __( 'Rotated corner text', 'vassilisdesign-elements' ), 'type' => Controls_Manager::TEXT, 'default' => 'GR / US' ) );
		$this->add_control( 'image', array( 'label' => __( 'Image', 'vassilisdesign-elements' ), 'type' => Controls_Manager::MEDIA ) );
		$this->add_control( 'image_alt', array( 'label' => __( 'Image description', 'vassilisdesign-elements' ), 'type' => Controls_Manager::TEXT, 'default' => 'Wine labels designed by VASSILISDESIGN' ) );
		$this->add_control(
			'fit',
			array(
				'label'   => __( 'Image display', 'vassilisdesign-elements' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'contain',
				'options' => array(
					'contain' => __( 'Packshot on white: fit', 'vassilisdesign-elements' ),
					'cover'   => __( 'Photo: fill', 'vassilisdesign-elements' ),
				),
			)
		);
		$this->add_control( 'cta', array( 'label' => __( 'Arrow button link', 'vassilisdesign-elements' ), 'type' => Controls_Manager::TEXT, 'default' => '#work' ) );
		$this->add_control( 'cta_label', array( 'label' => __( 'Arrow button label', 'vassilisdesign-elements' ), 'type' => Controls_Manager::TEXT, 'default' => 'See selected work' ) );
		$this->end_controls_section();
		$this->add_style_controls(
			array(
				array( 'text', 'wordmark', __( 'Wordmark', 'vassilisdesign-elements' ), '.vd-wordmark' ),
				array( 'color', 'stop', __( 'Wordmark full stop', 'vassilisdesign-elements' ), '.vd-wordmark .vd-stop', 'color' ),
				array( 'text', 'lead', __( 'Positioning', 'vassilisdesign-elements' ), '.vd-hero-lead' ),
				array( 'text', 'meta', __( 'Columns', 'vassilisdesign-elements' ), '.vd-hero-meta' ),
				array( 'color', 'meta_line', __( 'Column lines', 'vassilisdesign-elements' ), '.vd-hero-meta', 'border-top-color' ),
				array( 'text', 'vertical', __( 'Vertical text', 'vassilisdesign-elements' ), '.vd-hero-vertical' ),
				array( 'color', 'vertical_line', __( 'Vertical text line', 'vassilisdesign-elements' ), '.vd-hero-vertical', 'border-left-color' ),
				array( 'text', 'corner', __( 'Rotated corner text', 'vassilisdesign-elements' ), '.vd-hero-corner' ),
				array( 'color', 'band', __( 'Red band', 'vassilisdesign-elements' ), '.vd-hero-band', 'background-color' ),
				array( 'color', 'cta_bg', __( 'Arrow button', 'vassilisdesign-elements' ), '.vd-hero-cta', 'background-color' ),
				array( 'color', 'cta_icon', __( 'Arrow', 'vassilisdesign-elements' ), '.vd-hero-cta', 'color' ),
			)
		);
	}
	protected function render() {
		$s     = $this->get_settings_for_display();
		$chars = function ( $word ) {
			$out = '';
			foreach ( preg_split( '//u', (string) $word, -1, PREG_SPLIT_NO_EMPTY ) as $ch ) {
				$out .= '<span class="vd-ch">' . esc_html( $ch ) . '</span>';
			}
			return $out;
		};
		?>
		<section class="vd-hero vd-wrap" aria-label="<?php echo esc_attr( $s['label'] ); ?>">
			<h1 class="vd-wordmark" aria-label="<?php echo esc_attr( $s['label'] ); ?>">
				<span aria-hidden="true">
					<span class="vd-wm-line"><?php echo $chars( $s['line1'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
					<span class="vd-wm-line"><?php echo $chars( $s['line2'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><span class="vd-ch vd-stop">.</span></span>
				</span>
			</h1>
			<p class="vd-hero-lead"><?php echo vde_lines( $s['lead'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>
			<?php if ( $s['corner'] ) : ?>
				<p class="vd-hero-corner" aria-hidden="true"><?php echo esc_html( $s['corner'] ); ?></p>
			<?php endif; ?>
			<p class="vd-hero-meta vd-hero-meta-a"><?php echo vde_lines( $s['meta_a'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>
			<p class="vd-hero-meta vd-hero-meta-b"><?php echo vde_lines( $s['meta_b'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>
			<?php if ( $s['vertical'] ) : ?>
				<p class="vd-hero-vertical"><?php echo vde_lines( $s['vertical'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>
			<?php endif; ?>
			<div class="vd-hero-media">
				<div class="vd-hero-photo vd-photo<?php echo 'contain' === $s['fit'] ? ' vd-fit-contain' : ''; ?>">
					<?php echo $this->media_img( $s['image'], 'full', true, $s['image_alt'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</div>
				<div class="vd-hero-band" aria-hidden="true"></div>
				<?php if ( $s['cta'] ) : ?>
					<a class="vd-hero-cta vd-square" href="<?php echo esc_url( $s['cta'] ); ?>" aria-label="<?php echo esc_attr( $s['cta_label'] ); ?>"><?php echo vde_arrow(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a>
				<?php endif; ?>
			</div>
		</section>
		<?php
	}
}

/* ---------- Section heading ---------- */

class VDE_Widget_Section_Head extends VDE_Widget {
	public function get_name() {
		return 'vd-section-head';
	}
	public function get_title() {
		return __( 'VD Section heading', 'vassilisdesign-elements' );
	}
	protected function register_controls() {
		$this->start( __( 'Heading', 'vassilisdesign-elements' ) );
		$this->add_control( 'intro', array( 'label' => __( 'Intro (left)', 'vassilisdesign-elements' ), 'type' => Controls_Manager::TEXTAREA ) );
		$this->add_control( 'title', array( 'label' => __( 'Title (right, shown lowercase with a red full stop)', 'vassilisdesign-elements' ), 'type' => Controls_Manager::TEXT, 'default' => 'Selected work' ) );
		$this->add_control(
			'tag',
			array(
				'label'   => __( 'Heading level', 'vassilisdesign-elements' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'h2',
				'options' => array( 'h1' => 'H1', 'h2' => 'H2', 'h3' => 'H3' ),
			)
		);
		$this->end_controls_section();
		$this->add_style_controls(
			array(
				array( 'text', 'intro', __( 'Intro text', 'vassilisdesign-elements' ), '.vd-section-intro' ),
				array( 'color', 'dot', __( 'Intro square', 'vassilisdesign-elements' ), '.vd-dot', 'background-color' ),
				array( 'text', 'title', __( 'Title', 'vassilisdesign-elements' ), '.vd-display' ),
				array( 'color', 'stop', __( 'Title full stop', 'vassilisdesign-elements' ), '.vd-display .vd-stop', 'color' ),
			)
		);
	}
	protected function render() {
		$s = $this->get_settings_for_display();
		echo '<div class="vd-section-head vd-wrap">';
		if ( $s['intro'] ) {
			echo '<p class="vd-section-intro"><span class="vd-dot" aria-hidden="true"></span>' . esc_html( $s['intro'] ) . '</p>';
		}
		echo vde_display_title( $s['title'], $s['tag'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '</div>';
	}
}

/* ---------- Works grid ---------- */

class VDE_Widget_Works_Grid extends VDE_Widget {
	public function get_name() {
		return 'vd-works-grid';
	}
	public function get_title() {
		return __( 'VD Works grid', 'vassilisdesign-elements' );
	}
	protected function is_dynamic_content(): bool {
		return true;
	}
	protected function register_controls() {
		$this->start( __( 'Works', 'vassilisdesign-elements' ) );
		$this->add_control( 'count', array( 'label' => __( 'Number of Works', 'vassilisdesign-elements' ), 'type' => Controls_Manager::NUMBER, 'default' => 10, 'min' => 1, 'max' => 48, 'description' => __( 'Tip: a multiple of the Works per row fills every row.', 'vassilisdesign-elements' ) ) );
		$options = array( '' => __( 'All sectors', 'vassilisdesign-elements' ) );
		$terms   = get_terms( array( 'taxonomy' => 'work_sector', 'hide_empty' => false ) );
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $term ) {
				$options[ $term->slug ] = $term->name;
			}
		}
		$this->add_control(
			'source',
			array(
				'label'   => __( 'Show', 'vassilisdesign-elements' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'all',
				'options' => array(
					'all'    => __( 'All Works (by Order)', 'vassilisdesign-elements' ),
					'sector' => __( 'Works in one Sector', 'vassilisdesign-elements' ),
					'pick'   => __( 'Works I choose', 'vassilisdesign-elements' ),
				),
			)
		);
		unset( $options[''] );
		$this->add_control(
			'sector',
			array(
				'label'     => __( 'Sector', 'vassilisdesign-elements' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '',
				'options'   => array( '' => __( 'Choose a Sector', 'vassilisdesign-elements' ) ) + $options,
				'condition' => array( 'source' => 'sector' ),
			)
		);
		$works = array();
		foreach ( get_posts( array( 'post_type' => 'works', 'post_status' => 'publish', 'posts_per_page' => 200, 'orderby' => 'title', 'order' => 'ASC' ) ) as $work ) {
			$works[ $work->ID ] = $work->post_title;
		}
		$this->add_control(
			'works',
			array(
				'label'       => __( 'Works (in this order)', 'vassilisdesign-elements' ),
				'type'        => Controls_Manager::SELECT2,
				'multiple'    => true,
				'label_block' => true,
				'options'     => $works,
				'default'     => array(),
				'condition'   => array( 'source' => 'pick' ),
			)
		);
		$this->add_control( 'all_link', array( 'label' => __( '"All work" link text (empty to hide)', 'vassilisdesign-elements' ), 'type' => Controls_Manager::TEXT, 'default' => 'All work' ) );
		$this->add_control(
			'order_note',
			array(
				'type' => Controls_Manager::RAW_HTML,
				'raw'  => esc_html__( 'Order Works with the "Order" field on each Work (lowest first).', 'vassilisdesign-elements' ),
			)
		);
		$this->end_controls_section();

		$this->start_controls_section( 'layout', array( 'label' => __( 'Layout', 'vassilisdesign-elements' ) ) );
		$this->add_control(
			'columns',
			array(
				'label'       => __( 'Works per row (desktop)', 'vassilisdesign-elements' ),
				'type'        => Controls_Manager::SELECT,
				'default'     => '5',
				'options'     => array( '3' => '3', '4' => '4', '5' => '5', '6' => '6' ),
				'description' => __( 'Tablets show 3 per row, phones 2.', 'vassilisdesign-elements' ),
			)
		);
		$this->add_control(
			'full',
			array(
				'label'        => __( 'Full width (no side margins)', 'vassilisdesign-elements' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
			)
		);
		$this->add_control( 'gap', array( 'label' => __( 'Space between Works (px, empty = default)', 'vassilisdesign-elements' ), 'type' => Controls_Manager::NUMBER, 'default' => '', 'min' => 0, 'max' => 80 ) );
		$this->add_control(
			'overlay',
			array(
				'label'        => __( 'Red cover with text on hover', 'vassilisdesign-elements' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
				'description'  => __( 'Shows the Work\'s Excerpt, or the start of its content.', 'vassilisdesign-elements' ),
			)
		);
		$this->add_control(
			'captions',
			array(
				'label'        => __( 'Title and details under each image', 'vassilisdesign-elements' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
			)
		);
		$this->add_control(
			'staggered',
			array(
				'label'        => __( 'Staggered heights', 'vassilisdesign-elements' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
				'description'  => __( 'On: each column has its own image height. Off: all images the same size.', 'vassilisdesign-elements' ),
			)
		);
		$this->end_controls_section();
		$this->add_style_controls(
			array(
				array( 'text', 'client', __( 'Work title', 'vassilisdesign-elements' ), '.vd-tile-client' ),
				array( 'color', 'client_hover', __( 'Work title on hover', 'vassilisdesign-elements' ), '.vd-tile-link:hover .vd-tile-client', 'color' ),
				array( 'text', 'meta', __( 'Details under the title', 'vassilisdesign-elements' ), '.vd-tile-meta' ),
				array( 'text', 'hover', __( 'Text on hover', 'vassilisdesign-elements' ), '.vd-tile-hover-text > span' ),
				array( 'color', 'cover', __( 'Red cover / red block', 'vassilisdesign-elements' ), '.vd-red-block', 'background-color' ),
				array( 'text', 'link', __( '"All work" link', 'vassilisdesign-elements' ), '.vd-all-link a' ),
				array( 'color', 'link_line', __( '"All work" underline', 'vassilisdesign-elements' ), '.vd-all-link a', '--vd-link-line' ),
			)
		);
	}
	protected function render() {
		$s      = $this->get_settings_for_display();
		$raw    = (array) ( $this->get_raw_data()['settings'] ?? array() );
		$sector = isset( $raw['sector'] ) ? (string) $raw['sector'] : ''; // Read raw: Elementor blanks settings whose condition is not met.
		$source = isset( $raw['source'] ) ? $s['source'] : ( '' !== $sector ? 'sector' : 'all' ); // Widgets saved before "Show" existed keep their Sector.
		$full   = 'yes' === $s['full'];
		$grid   = vde_works_grid(
			array(
				'count'     => $s['count'],
				'sector'    => 'sector' === $source ? $sector : '',
				'ids'       => 'pick' === $source ? (array) $s['works'] : array(),
				'columns'   => $s['columns'],
				'gap'       => $s['gap'],
				'overlay'   => 'yes' === $s['overlay'],
				'captions'  => 'yes' === $s['captions'],
				'staggered' => 'yes' === $s['staggered'],
			)
		);
		echo $full ? '<div class="vd-bleed">' . $grid . '</div>' : '<div class="vd-wrap">' . $grid . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		if ( $s['all_link'] ) {
			printf( '<div class="vd-wrap"><p class="vd-all-link"><a class="vd-text-link" href="%s">%s %s</a></p></div>', esc_url( get_post_type_archive_link( 'works' ) ), esc_html( $s['all_link'] ), vde_arrow() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	}
}

/* ---------- Logo wall ---------- */

class VDE_Widget_Logo_Wall extends VDE_Widget {
	public function get_name() {
		return 'vd-logo-wall';
	}
	public function get_title() {
		return __( 'VD Logo wall', 'vassilisdesign-elements' );
	}
	protected function register_controls() {
		$this->start( __( 'Logos', 'vassilisdesign-elements' ) );
		$this->add_control( 'logos', array( 'label' => __( 'Logos (on white, any size)', 'vassilisdesign-elements' ), 'type' => Controls_Manager::GALLERY, 'default' => array() ) );
		$this->end_controls_section();
		$this->add_style_controls(
			array(
				array( 'color', 'lines', __( 'Grid lines', 'vassilisdesign-elements' ), '.vd-logos, .vd-logo-cell', 'border-color' ),
			)
		);
	}
	protected function render() {
		$s = $this->get_settings_for_display();
		if ( empty( $s['logos'] ) ) {
			return;
		}
		echo '<div class="vd-wrap"><ul class="vd-logos" role="list">';
		foreach ( $s['logos'] as $logo ) {
			$alt = ! empty( $logo['id'] ) ? get_post_meta( $logo['id'], '_wp_attachment_image_alt', true ) : '';
			if ( ! $alt && ! empty( $logo['id'] ) ) {
				$alt = get_the_title( $logo['id'] );
			}
			echo '<li class="vd-logo-cell"><span class="vd-logo-frame">' . $this->media_img( $logo, 'medium_large', false, $alt ) . '</span></li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo '</ul></div>';
	}
}

/* ---------- Numbered list ---------- */

class VDE_Widget_Numbered_List extends VDE_Widget {
	public function get_name() {
		return 'vd-numbered-list';
	}
	public function get_title() {
		return __( 'VD Numbered list', 'vassilisdesign-elements' );
	}
	protected function register_controls() {
		$this->start( __( 'Items', 'vassilisdesign-elements' ) );
		$r = new Repeater();
		$r->add_control( 'title', array( 'label' => __( 'Title', 'vassilisdesign-elements' ), 'type' => Controls_Manager::TEXT ) );
		$r->add_control( 'text', array( 'label' => __( 'Text', 'vassilisdesign-elements' ), 'type' => Controls_Manager::TEXTAREA ) );
		$this->add_control(
			'items',
			array(
				'label'       => __( 'Items', 'vassilisdesign-elements' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $r->get_controls(),
				'title_field' => '{{{ title }}}',
				'default'     => array(),
			)
		);
		$this->end_controls_section();
		$this->add_style_controls(
			array(
				array( 'text', 'number', __( 'Numbers', 'vassilisdesign-elements' ), '.vd-step-n' ),
				array( 'text', 'title', __( 'Titles', 'vassilisdesign-elements' ), '.vd-step-title' ),
				array( 'text', 'text', __( 'Text', 'vassilisdesign-elements' ), '.vd-step-text' ),
				array( 'color', 'lines', __( 'Lines', 'vassilisdesign-elements' ), '.vd-steps, .vd-step', 'border-color' ),
			)
		);
	}
	protected function render() {
		$s = $this->get_settings_for_display();
		if ( empty( $s['items'] ) ) {
			return;
		}
		echo '<div class="vd-wrap"><ol class="vd-steps" role="list">';
		foreach ( array_values( $s['items'] ) as $i => $item ) {
			printf(
				'<li class="vd-step"><span class="vd-step-n" aria-hidden="true">%s</span><h3 class="vd-step-title">%s</h3><p class="vd-step-text">%s</p></li>',
				esc_html( str_pad( (string) ( $i + 1 ), 2, '0', STR_PAD_LEFT ) ),
				esc_html( $item['title'] ),
				esc_html( $item['text'] )
			);
		}
		echo '</ol></div>';
	}
}

/* ---------- Studio ---------- */

class VDE_Widget_Studio extends VDE_Widget {
	public function get_name() {
		return 'vd-studio';
	}
	public function get_title() {
		return __( 'VD Studio', 'vassilisdesign-elements' );
	}
	protected function register_controls() {
		$this->start( __( 'Studio', 'vassilisdesign-elements' ) );
		$this->add_control( 'title', array( 'label' => __( 'Title', 'vassilisdesign-elements' ), 'type' => Controls_Manager::TEXT, 'default' => 'Studio' ) );
		$this->add_control( 'red_title', array( 'label' => __( 'Red box label', 'vassilisdesign-elements' ), 'type' => Controls_Manager::TEXT, 'default' => 'What we hold to' ) );
		$this->add_control( 'red_list', array( 'label' => __( 'Red box list (one per line)', 'vassilisdesign-elements' ), 'type' => Controls_Manager::TEXTAREA, 'default' => "Typography first\nDetail and proportion\nBuilt for production\nDesign and technology" ) );
		$this->add_control( 'side_title', array( 'label' => __( 'Side label', 'vassilisdesign-elements' ), 'type' => Controls_Manager::TEXT, 'default' => 'Industries' ) );
		$this->add_control( 'side_list', array( 'label' => __( 'Side list (one per line)', 'vassilisdesign-elements' ), 'type' => Controls_Manager::TEXTAREA, 'default' => "Wine\nHospitality and tourism\nFood and beverage\nProfessional services" ) );
		$this->add_control( 'image', array( 'label' => __( 'Image', 'vassilisdesign-elements' ), 'type' => Controls_Manager::MEDIA ) );
		$this->add_control( 'text', array( 'label' => __( 'Text (first paragraph is shown large)', 'vassilisdesign-elements' ), 'type' => Controls_Manager::WYSIWYG ) );
		$this->end_controls_section();
		$this->add_style_controls(
			array(
				array( 'text', 'title', __( 'Title', 'vassilisdesign-elements' ), '.vd-display' ),
				array( 'color', 'stop', __( 'Title full stop', 'vassilisdesign-elements' ), '.vd-display .vd-stop', 'color' ),
				array( 'color', 'red_bg', __( 'Red box', 'vassilisdesign-elements' ), '.vd-studio-red', 'background-color' ),
				array( 'text', 'red_title', __( 'Red box label', 'vassilisdesign-elements' ), '.vd-studio-red-title' ),
				array( 'text', 'red_list', __( 'Red box list', 'vassilisdesign-elements' ), '.vd-studio-red-list' ),
				array( 'text', 'side_title', __( 'Side label', 'vassilisdesign-elements' ), '.vd-red-label' ),
				array( 'text', 'side_list', __( 'Side list', 'vassilisdesign-elements' ), '.vd-studio-side-list' ),
				array( 'text', 'intro', __( 'First paragraph', 'vassilisdesign-elements' ), '.vd-studio-copy p:first-child' ),
				array( 'text', 'body', __( 'Other paragraphs', 'vassilisdesign-elements' ), '.vd-studio-copy p:not(:first-child)' ),
				array( 'color', 'circle', __( 'Circle', 'vassilisdesign-elements' ), '.vd-studio-circle', 'background-color' ),
			)
		);
	}
	protected function render() {
		$s = $this->get_settings_for_display();
		?>
		<div class="vd-studio-grid vd-wrap">
			<?php echo vde_display_title( $s['title'], 'h2' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<div class="vd-studio-red">
				<p class="vd-studio-red-title"><?php echo esc_html( $s['red_title'] ); ?></p>
				<p class="vd-studio-red-list"><?php echo vde_lines( $s['red_list'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>
			</div>
			<div class="vd-studio-side">
				<p class="vd-red-label"><?php echo esc_html( $s['side_title'] ); ?></p>
				<p class="vd-studio-side-list"><?php echo vde_lines( $s['side_list'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>
			</div>
			<div class="vd-studio-media">
				<span class="vd-studio-circle" aria-hidden="true"></span>
				<div class="vd-studio-photo vd-photo vd-fit-contain"><?php echo $this->media_img( $s['image'], 'large', false, '' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
			</div>
			<div class="vd-studio-copy"><?php echo wp_kses_post( $s['text'] ); ?></div>
			<span class="vd-plus" aria-hidden="true"></span>
			<span class="vd-dots" aria-hidden="true"></span>
		</div>
		<?php
	}
}

/* ---------- Client index ---------- */

class VDE_Widget_Client_Index extends VDE_Widget {
	public function get_name() {
		return 'vd-client-index';
	}
	public function get_title() {
		return __( 'VD Client index', 'vassilisdesign-elements' );
	}
	protected function register_controls() {
		$this->start( __( 'Clients', 'vassilisdesign-elements' ) );
		$r = new Repeater();
		$r->add_control( 'title', array( 'label' => __( 'Sector', 'vassilisdesign-elements' ), 'type' => Controls_Manager::TEXT ) );
		$r->add_control( 'names', array( 'label' => __( 'Clients (one per line)', 'vassilisdesign-elements' ), 'type' => Controls_Manager::TEXTAREA, 'rows' => 10 ) );
		$this->add_control(
			'groups',
			array(
				'label'       => __( 'Groups', 'vassilisdesign-elements' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $r->get_controls(),
				'title_field' => '{{{ title }}}',
				'default'     => array(),
			)
		);
		$this->end_controls_section();
		$this->add_style_controls(
			array(
				array( 'text', 'sector', __( 'Sector titles', 'vassilisdesign-elements' ), '.vd-client-sector' ),
				array( 'color', 'sector_line', __( 'Sector title line', 'vassilisdesign-elements' ), '.vd-client-sector', 'border-bottom-color' ),
				array( 'text', 'names', __( 'Client names', 'vassilisdesign-elements' ), '.vd-client-list li' ),
				array( 'color', 'name_lines', __( 'Lines between names', 'vassilisdesign-elements' ), '.vd-client-list li', 'border-bottom-color' ),
			)
		);
	}
	protected function render() {
		$s = $this->get_settings_for_display();
		if ( empty( $s['groups'] ) ) {
			return;
		}
		echo '<div class="vd-wrap vd-client-groups">';
		foreach ( $s['groups'] as $group ) {
			$names = array_filter( array_map( 'trim', explode( "\n", (string) $group['names'] ) ) );
			echo '<div class="vd-client-group"><h3 class="vd-client-sector">' . esc_html( $group['title'] ) . '</h3><ul class="vd-client-list" role="list">';
			foreach ( $names as $name ) {
				echo '<li>' . esc_html( $name ) . '</li>';
			}
			echo '</ul></div>';
		}
		echo '</div>';
	}
}

/* ---------- Contact intro ---------- */

class VDE_Widget_Contact_Intro extends VDE_Widget {
	public function get_name() {
		return 'vd-contact-intro';
	}
	public function get_title() {
		return __( 'VD Contact intro', 'vassilisdesign-elements' );
	}
	protected function register_controls() {
		$this->start( __( 'Contact', 'vassilisdesign-elements' ) );
		$this->add_control( 'title', array( 'label' => __( 'Title', 'vassilisdesign-elements' ), 'type' => Controls_Manager::TEXT, 'default' => 'Start a project' ) );
		$this->add_control( 'lead', array( 'label' => __( 'Text', 'vassilisdesign-elements' ), 'type' => Controls_Manager::TEXTAREA, 'default' => 'Tell us about your brand, product or website. We reply to every enquiry.' ) );
		$this->add_control( 'direct', array( 'label' => __( 'Line above the contact details', 'vassilisdesign-elements' ), 'type' => Controls_Manager::TEXT, 'default' => 'Or write to us directly' ) );
		$this->add_control(
			'note',
			array(
				'type' => Controls_Manager::RAW_HTML,
				'raw'  => esc_html__( 'Email and phone come from Appearance → Customize → Studio details.', 'vassilisdesign-elements' ),
			)
		);
		$this->end_controls_section();
		$this->add_style_controls(
			array(
				array( 'text', 'title', __( 'Title', 'vassilisdesign-elements' ), '.vd-display' ),
				array( 'color', 'stop', __( 'Title full stop', 'vassilisdesign-elements' ), '.vd-display .vd-stop', 'color' ),
				array( 'text', 'lead', __( 'Text', 'vassilisdesign-elements' ), '.vd-contact-lead' ),
				array( 'text', 'direct', __( 'Line above contact details', 'vassilisdesign-elements' ), '.vd-contact-direct' ),
				array( 'text', 'links', __( 'Email and phone', 'vassilisdesign-elements' ), '.vd-contact-direct a' ),
			)
		);
	}
	protected function render() {
		$s = $this->get_settings_for_display();
		echo '<div class="vd-contact-intro">';
		echo vde_display_title( $s['title'], 'h2' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		if ( $s['lead'] ) {
			echo '<p class="vd-contact-lead">' . esc_html( $s['lead'] ) . '</p>';
		}
		echo '<p class="vd-contact-direct">' . ( $s['direct'] ? esc_html( $s['direct'] ) . '<br>' : '' ) . vde_contact_lines() . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '</div>';
	}
}

/* ---------- Single Work (for Elementor Pro Theme Builder) ---------- */

abstract class VDE_Work_Widget extends VDE_Widget {
	protected function is_dynamic_content(): bool {
		return true;
	}
	protected function register_controls() {
		$this->start( __( 'Work', 'vassilisdesign-elements' ) );
		$this->add_control(
			'note',
			array(
				'type' => Controls_Manager::RAW_HTML,
				'raw'  => esc_html__( 'Shows the current Work. Use inside a Theme Builder "Single" template for Works.', 'vassilisdesign-elements' ),
			)
		);
		$this->end_controls_section();
		$this->add_style_controls( $this->style_items() );
	}
	protected function style_items() {
		return array();
	}
	/** The current Work, or the latest one while previewing a template in the editor. */
	protected function work() {
		$post = get_post();
		if ( $post && 'works' === $post->post_type ) {
			return $post;
		}
		$latest = get_posts( array( 'post_type' => 'works', 'posts_per_page' => 1 ) );
		return $latest ? $latest[0] : null;
	}
}

class VDE_Widget_Work_Header extends VDE_Work_Widget {
	public function get_name() {
		return 'vd-work-header';
	}
	public function get_title() {
		return __( 'VD Work header', 'vassilisdesign-elements' );
	}
	protected function style_items() {
		return array(
			array( 'text', 'back', __( '"All work" link', 'vassilisdesign-elements' ), '.vd-case-back' ),
			array( 'text', 'meta_label', __( 'Detail labels', 'vassilisdesign-elements' ), '.vd-case-meta dt' ),
			array( 'text', 'meta_value', __( 'Detail values', 'vassilisdesign-elements' ), '.vd-case-meta dd' ),
			array( 'color', 'meta_line', __( 'Detail lines', 'vassilisdesign-elements' ), '.vd-case-meta > div', 'border-left-color' ),
			array( 'text', 'index', __( 'Project number', 'vassilisdesign-elements' ), '.vd-case-index' ),
			array( 'text', 'title', __( 'Title', 'vassilisdesign-elements' ), '.vd-case-title' ),
			array( 'color', 'stop', __( 'Title full stop', 'vassilisdesign-elements' ), '.vd-case-title .vd-stop', 'color' ),
			array( 'color', 'red_bg', __( 'Red box', 'vassilisdesign-elements' ), '.vd-case-red', 'background-color' ),
			array( 'text', 'red_title', __( 'Red box label', 'vassilisdesign-elements' ), '.vd-case-red-title' ),
			array( 'text', 'facts', __( 'Red box list', 'vassilisdesign-elements' ), '.vd-case-facts li' ),
		);
	}
	protected function render() {
		$w = $this->work();
		if ( $w ) {
			echo vde_work_header( $w ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	}
}

class VDE_Widget_Work_Intro extends VDE_Work_Widget {
	public function get_name() {
		return 'vd-work-intro';
	}
	public function get_title() {
		return __( 'VD Work cover and summary', 'vassilisdesign-elements' );
	}
	protected function style_items() {
		return array(
			array( 'text', 'label', __( 'Label', 'vassilisdesign-elements' ), '.vd-case-label' ),
			array( 'text', 'summary', __( 'Summary', 'vassilisdesign-elements' ), '.vd-case-summary' ),
			array( 'text', 'body', __( 'Description', 'vassilisdesign-elements' ), '.vd-case-text .vd-prose' ),
		);
	}
	protected function render() {
		$w = $this->work();
		if ( $w ) {
			echo vde_work_intro( $w ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	}
}

class VDE_Widget_Work_Gallery extends VDE_Work_Widget {
	public function get_name() {
		return 'vd-work-gallery';
	}
	public function get_title() {
		return __( 'VD Work gallery', 'vassilisdesign-elements' );
	}
	protected function render() {
		$w = $this->work();
		if ( $w ) {
			echo vde_work_gallery( $w ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	}
}

class VDE_Widget_Works_Archive extends VDE_Widget {
	public function get_name() {
		return 'vd-works-archive';
	}
	public function get_title() {
		return __( 'VD Works archive', 'vassilisdesign-elements' );
	}
	protected function is_dynamic_content(): bool {
		return true;
	}
	protected function register_controls() {
		$this->start( __( 'Works archive', 'vassilisdesign-elements' ) );
		$this->add_control(
			'note',
			array(
				'type' => Controls_Manager::RAW_HTML,
				'raw'  => esc_html__( 'Title, Sector filter and all Works of the current archive. Use inside a Theme Builder "Archive" template for Works.', 'vassilisdesign-elements' ),
			)
		);
		$this->end_controls_section();
		$this->add_style_controls(
			array(
				array( 'text', 'title', __( 'Title', 'vassilisdesign-elements' ), '.vd-display' ),
				array( 'color', 'stop', __( 'Title full stop', 'vassilisdesign-elements' ), '.vd-display .vd-stop', 'color' ),
				array( 'text', 'filter', __( 'Sector filter', 'vassilisdesign-elements' ), '.vd-filter a' ),
				array( 'text', 'client', __( 'Work title', 'vassilisdesign-elements' ), '.vd-tile-client' ),
				array( 'text', 'meta', __( 'Details under the title', 'vassilisdesign-elements' ), '.vd-tile-meta' ),
			)
		);
	}
	protected function render() {
		echo vde_works_archive(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}

class VDE_Widget_Next_Work extends VDE_Work_Widget {
	public function get_name() {
		return 'vd-next-work';
	}
	public function get_title() {
		return __( 'VD Next Work', 'vassilisdesign-elements' );
	}
	protected function style_items() {
		return array(
			array( 'text', 'label', __( '"Next project" label', 'vassilisdesign-elements' ), '.vd-case-next-label' ),
			array( 'text', 'client', __( 'Next Work title', 'vassilisdesign-elements' ), '.vd-case-next-client' ),
			array( 'color', 'stop', __( 'Title full stop', 'vassilisdesign-elements' ), '.vd-case-next-client .vd-stop', 'color' ),
			array( 'color', 'line', __( 'Top line', 'vassilisdesign-elements' ), '.vd-case-next-link', 'border-top-color' ),
		);
	}
	protected function render() {
		$w = $this->work();
		if ( $w ) {
			echo vde_next_work( $w ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	}
}
